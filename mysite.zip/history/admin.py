from django.contrib import admin
from . import models

class CategoryAdmin(admin.ModelAdmin):
    list_display     = ['cat_name', 'ordering', 'status']
    search_fields    = ['title']
    list_filter      = ['status']


class ServiceAdmin(admin.ModelAdmin):
    list_display     = ['catagory','title', 'photo','views','ordering', 'status']
    search_fields    = ['title']
    list_filter      = ['status']

admin.site.register(models.Category, CategoryAdmin)
admin.site.register(models.Service, ServiceAdmin)